package com.testproject.githubactionsexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GithubActionsExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
